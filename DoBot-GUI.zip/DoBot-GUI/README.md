# DoBot
This is a repository for the Dobot Pick &amp; Place group project
